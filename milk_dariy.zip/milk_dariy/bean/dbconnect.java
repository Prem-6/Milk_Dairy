package md;
import java.sql.*;
public class dbconnect
{
private Connection con;
public Statement stmt;
public String getcon()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
con=DriverManager.getConnection("Jdbc:Odbc:ananda1");
stmt=con.createStatement();
}
catch(Exception e)
{
System.out.println(e);
}
return" ";
}
}